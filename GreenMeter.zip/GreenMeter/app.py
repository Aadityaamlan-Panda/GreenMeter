from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Route for the homepage
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle energy data submission
@app.route('/submit', methods=['POST'])
def submit():
    data = request.form
    # Retrieve user input
    energy_consumption = float(data.get('energy_consumption', 0))
    solar_efficiency = float(data.get('solar_efficiency', 0))

    # Simple calculation
    potential_savings = energy_consumption * (solar_efficiency / 100)
    return render_template('results.html', 
                           energy_consumption=energy_consumption,
                           potential_savings=potential_savings)

if __name__ == "__main__":
    app.run(debug=True)
