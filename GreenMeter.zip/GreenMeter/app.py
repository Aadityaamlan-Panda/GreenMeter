from flask import Flask, render_template, request

app = Flask(__name__)

# Helper function to calculate potential savings
def calculate_savings(energy_consumption, solar_efficiency, panel_power, panel_area, solar_irradiance):
    # Default values for optional inputs
    
    solar_energy_generated = energy_consumption * (solar_efficiency / 100) 
    
    energy_savings = min(solar_energy_generated, energy_consumption)
    
    # Cost calculations (assume cost per kWh = $0.15)
    cost_savings = energy_savings * 0.15
    return energy_savings, cost_savings, solar_energy_generated

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    # Retrieve user input
    energy_consumption = float(request.form.get('energy_consumption', 0))
    solar_efficiency = float(request.form.get('solar_efficiency', 0))
    panel_power = request.form.get('panel_power', 0)
    panel_area = request.form.get('panel_area', 0)
    solar_irradiance = request.form.get('solar_irradiance', 0)
    
    # Convert optional inputs to float
    panel_power = float(panel_power) if panel_power else None
    panel_area = float(panel_area) if panel_area else None
    solar_irradiance = float(solar_irradiance) if solar_irradiance else None
    
    # Calculate savings
    potential_savings, cost_savings, solar_energy_generated = calculate_savings(
        energy_consumption, solar_efficiency, panel_power, panel_area, solar_irradiance
    )
    
    # Pass results to the results page
    return render_template('results.html', 
                           energy_consumption=energy_consumption,
                           energy_savings=potential_savings, 
                           cost_savings=cost_savings, 
                           solar_energy_generated=solar_energy_generated)

if __name__ == "__main__":
    app.run(debug=True)
