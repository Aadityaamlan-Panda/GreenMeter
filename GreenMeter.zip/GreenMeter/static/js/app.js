document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('theme-toggle');
    const body = document.body;

    // Check if dark mode is saved in localStorage
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        body.classList.toggle('dark-mode', savedTheme === 'dark');
    }

    // Add click event listener to toggle dark mode
    if (toggleButton) {  // Make sure the button exists on the page
        toggleButton.addEventListener('click', () => {
            body.classList.toggle('dark-mode');
            // Save the user's theme preference
            localStorage.setItem('theme', body.classList.contains('dark-mode') ? 'dark' : 'light');
        });
    }
});
